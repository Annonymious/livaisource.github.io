//
//  main.cpp
//  BullCowGame
//
//  Created by Noor Mohamed on 06/06/18.
//  Copyright © 2018 Noor. All rights reserved.
//

#include <iostream>
#include <string>
#include "FBullCowGame.hpp"

using int32 = int;
using FText = std::string;

void PrintIntro();
void PlayGame();
FText GetValidGuess();
bool AskToPlayAgain();
void PrintGameSummary();
// provide a method for counting bulls and cows, and increasing the turn

FBullCowGame BCGame;

int main()
{
    bool bPlayAgain = false;
    
    do
    {
    PrintIntro();
    //loop for the number of turns asking for guesses
    PlayGame();
    bPlayAgain = AskToPlayAgain();
    }
    // or we can directly put while(AskToPlayAgain()) without creating bPlayAgain
    while(bPlayAgain);
    
    
    
    return 0;
}

void PrintIntro()
{
    // introduce the game
    std::cout << "\n\nWelcome to Bulls and Cows, a fun word game.\n";
    std::cout << "Can you guess the " << BCGame.GetHiddenWordLength();
    std::cout << " letter isogram I'm thinking of?\n";
    return;
}


void PlayGame()
{
    BCGame.Reset();
    int32 MaxTries = BCGame.GetMaxTries();
    
    // loop for the number of turns asking for guess
    int32 count = 1;
    while (!BCGame.IsGameWon() && BCGame.GetCurrentTry() <= MaxTries) { // TODO: change from FOR to WHILE loop once we are validating tries
        FText Guess = GetValidGuess();
        
        EGuessStatus Status;
        Status = BCGame.CheckGuessValidity(Guess);
        
        // submit valid guess to the game, and recieve counts
        FBullCowCount BullCowCount = BCGame.SubmitValidGuess(Guess);
        // print the number of bulls and cows
        std::cout << "Bulls = " << BullCowCount.Bulls;
        std::cout << ". Cows = " << BullCowCount.Cows << std::endl;
        std::cout << std::endl;
        count++;
    }
    // TODO: summarise game
    PrintGameSummary();
    return;
}

/* we changed the name from "GetGuess" to "GetGuessAndPrintBack" for readability
 Select and Command+Ctrl+e for Xcode and Ctrl+r for Visual Studio */

// loop continuosly until the user gives a valid guess
FText GetValidGuess() // TODO: change to get valid guess
{
    EGuessStatus Status = EGuessStatus::Invalid_Status;
    FText  Guess = "";

    do {
        // get a guess from the player
        int32 CurrentTry = BCGame.GetCurrentTry();
        std::cout << "Try " << CurrentTry << ". Enter your guess: ";
        getline(std::cin,Guess);
        std::cout << std::endl;
        
        Status = BCGame.CheckGuessValidity(Guess);
        switch (Status) {
            case EGuessStatus::Not_Isogram:
                std::cout << "Please Enter an Isogram.\n";
                break;
            case EGuessStatus::Wrong_Length:
                std::cout << "Please enter a " << BCGame.GetHiddenWordLength() << " letter word.\n";
                break;
            case EGuessStatus::Not_Lowercase:
                std::cout << "Please enter all letters in lowercase.\n";
                break;
            default:
                // assume the guess is valid
                break;
        }
    } while(Status != EGuessStatus::OK);
    return Guess;
}

bool AskToPlayAgain()
{
    
    std::cout << "Do you want to play again? (y/n)";
    std::cout << std::endl;
    FText Response = "";
    getline(std::cin, Response);
    return (Response[0] == 'Y') || (Response[0] == 'y');
}

void PrintGameSummary() {
    if (BCGame.IsGameWon()) {
        std::cout << "YOU WON!!!.\n";
    }
    else {
        std::cout << "Aww.. Bad luck. Better Luck next time!.\n";
    }
}

