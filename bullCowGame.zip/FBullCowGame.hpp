//
//  FBullCowGame.hpp
//  BullCowGame
//
//  Created by Noor Mohamed on 08/06/18.
//  Copyright © 2018 Noor. All rights reserved.
//

#include <string>

using int32 = int;
using FString = std::string;

struct FBullCowCount
{
    int32 Bulls = 0;
    int32 Cows = 0;
};

enum class EGuessStatus
{
    Invalid_Status,
    OK,
    Not_Isogram,
    Wrong_Length,
    Not_Lowercase
};

class FBullCowGame
{
public:
    FBullCowGame();
    int32 GetMaxTries() const;
    int32 GetCurrentTry() const;
    int32 GetHiddenWordLength() const;
    
    bool IsGameWon() const;
    EGuessStatus CheckGuessValidity(FString) const; // TODO: to make a more rich return value
    
    void Reset(); // TODO: to make a more rich return value
    //counts number of cows and bulls and increases it. assuming a valid guess.
    FBullCowCount SubmitValidGuess(FString);
    
    
private:
    //Initialized with value inside the constructer of this class
    int32 MyCurrentTries;
    int32 MyMaxTries;
    FString MyHiddenWord;
    bool bGameIsWon;
    
    bool IsIsogram(FString) const;
    bool IsLowercase(FString) const;
};

